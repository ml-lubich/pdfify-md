#!/usr/bin/env node

// Simple wrapper that calls the main markpdf CLI
require('@ml-lubich/markpdf/dist/cli.js');

